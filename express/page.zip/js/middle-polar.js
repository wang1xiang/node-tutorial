
function createPolar(data,options) {
  var chart = new G2.Chart({
    container: options.container,
    // forceFit: true,
    height: 300,
    width: 200,
    padding: [0,0,60,0]
  });
  chart.source(data, {
    'percent': {
      min: 0,
      max: 2
    }
  });
  chart.tooltip({
    title: 'question'
  });
  chart.legend(false);
  chart.coord('polar', {
    startAngle: 0.5* Math.PI,
    endAngle: 2.5 * Math.PI,
    innerRadius: 0.1
  }).transpose();
  chart.interval().position('question*percent').size(20)
  .color('question', ['#943060','#a06a61','#2c7db5','#3ca59b'])
  // .tooltip('percent', function(val) {
  //   return {
  //     name: '占比',
  //     value: val * 100 + '%'
  //   };
  // })
  // .label('percent', {
  //   offset: -5
  // });
  // data.map(function(obj) {
  //   chart.guide().text({
  //     position: [obj.question, 0],
  //     content: obj.question + ' ',
  //     style: {
  //       textAlign: 'right'
  //     }
  //   });
  // });
  chart.render();
  return chart
}