function createPie(data, options) {
  var chart = new G2.Chart({
    container: options.container,
    forceFit: true,
    height: 153,
    padding: [0, 0, 0, 0]
  });
  chart.source(data);
  chart.coord("theta", {
    radius: 1
  });
  chart.legend(false);
  let lists=new Array();
  for(var i=0;i<data.length;i++){
    lists.push(data[i].percent)
  }
  lists.sort()
  if(isNaN(lists.pop())){
    for(var i=0;i<data.length;i++){
      data[0].percent=1;
      data[1].percent=0;
      data[2].percent=0;
      data[3].percent=0;
    }
    chart
    .intervalStack()
    .position("percent")
    .tooltip(false)
    .color("item", "#2c7db5");
    chart.guide().text({
      position: ['50%', '50%'],
      content: `暂无异常`,
      style: {
        fill: "#fff",
        fontSize: 12,
        textAlign: "center",
        textBaseline: "middle"
      }
    });
  }else{
    chart
    .intervalStack()
    .position("percent")
    .color("item", ["#943060", "#a06a61", "#2c7db5", "#3ca59b"])
    .tooltip("item*count", function(item, count) {
      return {
        name: item,
        value: count
      };
    });
    // chart.tooltip({
    //   showTitle: false,
    //   itemTpl:
    //     '<li><span style="background-color:{color};" class="g2-tooltip-marker"></span>{name}: {value}</li>'
    // });
   };
  chart.render();
  return chart
}
