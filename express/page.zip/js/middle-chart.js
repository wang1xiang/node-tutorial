function createChart(data, options) {
  const fields = [];
  Object.keys(data[0]).forEach(key => {
    if (key !== "name") {
      fields.push(key);
    }
  });

  var chart = new G2.Chart({
    container: options.container,
    forceFit: true,
    height: 220,
    padding: [30, 40, 76, 80]
  });
  chart.source(data, {
    time: {
      range: [0.05, 0.95]
    }
  });
  // chart.legend({
  //   position: "top-right",
  //   offsetY: -4,
  // });
  chart.legend(false)
  chart.axis("time", {
    label: {
      // offset: 12,
      textStyle: {
        fill: "#fff"
      }
    }
  });
  chart.scale("used", {
    min: 0,
    tickCount: 5,
    // alias: "单位(核)",
    formatter: val => {
      return formatterNumber(val);
    }
  });
  chart.axis("used", {
    label: {
      textStyle: {
        fill: "#fff"
      }
    },
    grid: {
      lineStyle: {
        stroke: "#223659",
        lineWidth: 1,
        lineDash: null
      }
    }
  });
  chart.guide().text({
    position: ['-4%', '-20%'],
    content: `单位(${options.unit})`,
    style: {
      fill: "#2e6aac",
      fontSize: 12,
      textAlign: "center",
      textBaseline: "middle"
    }
  });
  chart
    .intervalStack()
    .position("time*used")
    .color("name", options.colors);
  chart.render();
  return chart;
}

function createBottomChart(data, options) {
  const fields = [];
  Object.keys(data[0]).forEach(key => {
    if (key !== "name") {
      fields.push(key);
    }
  });
  var chart = new G2.Chart({
    container: options.container,
    forceFit: true,
    height: 220,
    padding: [30, 40, 76, 80]
  });
  chart.source(data);
  chart.legend({
    position: "top-right",
    offsetY: -4,
  });
  chart.axis("time", {
    label: {
      // offset: 12,
      textStyle: {
        fill: "#fff"
      }
    }
  });
  chart.scale("used", {
    alias: "已使用",
    formatter: val => {
      return formatterNumber(val) + "" + options.unit;
		}
  });
  chart.axis("used", {
    label: {
      textStyle: {
        fill: "#fff"
      }
    },
    grid: {
      lineStyle: {
        stroke: "#223659",
        lineWidth: 1,
        lineDash: null
      }
    }
  });
  chart
    .interval()
    .position("time*used")
    .color(options.colors);
  chart.render();
  return chart;
}

function createRightChart(data, options) {
	  const fields = [];
	  Object.keys(data[0]).forEach(key => {
	    if (key !== "name") {
	      fields.push(key);
	    }
	  });

	  var chart = new G2.Chart({
	    container: options.container,
	    width:484,
	    height: 220,
	    padding: [30, 40, 65,65]
	  });
	  chart.source(data);
    chart.scale('used',  {
      min: 0,
      ticks: [ 0, 20, 40, 60, 80, 100 ]
    });
    chart.scale('time',  {
      tickCount: 5
    });
	  
	  chart.tooltip({
	    crosshairs: {
	      type: 'line'
	    }
	  });
	  chart.axis('used', {
	    label: {
	      offset:0,
	      textStyle: {
	        fill: "#fff"
	      },
	      formatter: function formatter(val) {
	        return formatterNumber(val)
	      }
	    },
	    grid: {
	      lineStyle: {
	          stroke: '#304B67', // 网格线的颜色
	          lineWidth: 1, // 网格线的粗细
	          lineDash: null // 网格线的虚线配置，第一个参数描述虚线的实部占多少像素，第二个参数描述虚线的虚部占多少像素
	      }
	    },
	    line: null,
	    tickLine: null
	  });
	  chart.axis('time', {
	    label: {
	      textStyle: {
	        fill: "#fff"
	      }
	    },
	    line: {
	      lineWidth: 1, // 设置线的宽度
	      stroke: "#314D69 ", // 设置线的颜色
	      lineDash: null // 设置虚线样式
	    },
	    tickLine: null
	  });
	  chart.legend({
	    position: 'top-right',
	    textStyle: {
	      fill: "#fff"
	    },
	    offsetY: -3
    });
    chart.guide().text({
      position: ['-6%', '-14%'],
      content: `单位(${options.unit})`,
      style: {
        fill: "#fff",
        fontSize: 12,
        textAlign: "center",
        textBaseline: "middle"
      }
    });
	  chart.line().position('time*used').color('group',options.colors).shape('smooth').style({
	    lineWidth:2
	  });
	  if(options.flag){
	    chart.area().position('time*used').color('group',options.colors).opacity(0.21);
	  }
	  chart.point().position('time*used').color('#FFFFFF').size(2).shape('circle').opacity(0.52).style({
	    stroke: '#fff',
	    lineWidth: 1
	  });
	  chart.render();
	  return chart;
	}