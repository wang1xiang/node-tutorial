function formatterNumber(number) {
  let str = "" + number;
  let count = parseInt((str.length - 1) / 3);
  if (!count) return str;
  let arr = [];
  for (let index = 1; index <= count; index++) {
    const start = str.length - index * 3;
    const end = start + 3 > str.length ? str.length : start + 3;
    const current = str.substring(start, end);
    arr.unshift(current);
  }
  arr.unshift(str.substring(0, str.length - count * 3));
  return arr.join(",");
}
