// 12.4 页面改版为资源使用率
let overallApp = new Vue({
  el: '#overallApp',
  data: {
    overallData: [],
  },
  methods: {
    setOverallData(data) {
      this.overallData = data;
    }
  }
});

let warningApp = new Vue({
  el: '#warningApp',
  data: {
    warningData: []
  },
  methods: {
    setWarningData(data) {
      this.warningData = data;
    }
  }
});
let machineStateApp = new Vue({
  el: '#machineState',
  data: {
    firstFlag: true,
    groupData: [],
    machineData: [],
    machineData1: []
  },
  methods: {
    setMachineData(data1, data2) {
      this.machineData = data1;
      this.machineData1 = data2;
    },
    setGroupData(data) {
      this.groupData = data
    }
  }
})
/* 数据初始化和更新 */
// 总数据初始化和更新
function setOverallData() {
  $.ajax({
    url: `http://${window.url}/wuling/resource/usageRate`,
    data: {},
    type: 'POST',
    dataType: 'json',
    success: function(res) {
      const data = res.responseBody
      overallApp.setOverallData(data)
    }
  })
}
function dateFormat (date, fmt) {
  const o = {
    'M+': date.getMonth() + 1,
    'd+': date.getDate(),
    'h+': date.getHours(),
    'm+': date.getMinutes(),
    's+': date.getSeconds(),
    'q+': Math.floor((date.getMonth() + 3) / 3),
    S: date.getMilliseconds()
  }
  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
  }
  for (let k in o) {
    if (new RegExp('(' + k + ')').test(fmt)) {
      fmt = fmt.replace(RegExp.$1, RegExp.$1.length === 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length))
    }
  }
  return fmt
}
// 警告初始化和更新
function setWarningData(data) {
  $.ajax({
    url: `http://${window.url}/wuling/alarm/top5`,
    data: {},
    type: 'POST',
    dataType: 'json',
    success: function(res) {
      let data = res.responseBody
      data = data.map(item => {
        item.time = dateFormat(new Date(item.time), 'yyyy-MM-dd hh:mm:ss')
        item.level = '严重'
        return item
      })
      warningApp.setWarningData(data)
    }
  })
}
function setMachineData() {
  $.ajax({
    url: `http://${window.url}/wuling/alarm/count`,
    data: {},
    type: 'POST',
    dataType: 'json',
    success: function(res) {
      const data = res.responseBody
      const resNet = data.network
      let network = [
        {
          'item': '严重',
          'count': resNet.critical || 0
        },
        {
          'item': '主要',
          'count': resNet.major || 0
        },
        {
          'item': '次要',
          'count': resNet.minor || 0
        },
        {
          'item': '警告',
          'count': resNet.warn || 0
        }
      ]
      const resSys = data.system
      let system = [
        {
          'item': '严重',
          'count': resSys.critical || 0
        },
        {
          'item': '主要',
          'count': resSys.major || 0
        },
        {
          'item': '次要',
          'count': resSys.minor || 0
        },
        {
          'item': '警告',
          'count': resSys.warn || 0
        }
      ]
      machineStateApp.setMachineData(network, system)
      if (machineStateApp.firstFlag) {
        initPie(network, system)
        machineStateApp.firstFlag = false
      } else {
        updatePie(network, system)
      }
    }
  })
}
function setGroupData(data) {
  machineStateApp.setGroupData(data)
}
// 初始化饼状图
let pieChart1 = null;
let pieChart2 = null;
function initPie(arr1, arr2) {
  pieChart1 = createPie(transformPieData(arr1), {
    container: 'mountNode71'
  });
  pieChart2 = createPie(transformPieData(arr2), {
    container: 'mountNode72'
  });
}
// 处理饼状图的数据（添加百分比）
function transformPieData(arr) {
  let totalCount = arr.reduce((sum, item) => {
    return sum + item.count;
  }, 0);
  arr.forEach(item => {
    item.percent = parseFloat((item.count / totalCount).toFixed(2));
  });
  return arr;
}
// 初始化柱状图
function getTree(data){
  for(var i=0;i<data.length;i++){
    if(data[i].group.length>3){
      data[i].group= data[i].group.substring(0,3);
    }
  }
}
let intervalChart1 = null;
let intervalChart2 = null;
let intervalChart3 = null;
function initInterval() {
  $.ajax({
    url: `http://${window.url}/wuling/resource/memoryUsed`,
    data: {},
    type: 'POST',
    dataType: 'json',
    success: function(res) {
      let data = res.responseBody
      data = data.map(item => {
        item.used = Number(item.used)
        return item
      })
      intervalChart1 = createChart(data, {
        container: 'mountNode1',
        unit: '%',
        colors: ['#3263e7']
      });
    }
  })
  $.ajax({
    url: `http://${window.url}/wuling/resource/dataSet`,
    data: {},
    type: 'POST',
    dataType: 'json',
    success: function(res) {
      let data = res.responseBody
      data = data.map(item => {
        item.used = Number(item.used)
        return item
      })
      intervalChart2 = createChart(data, {
        container: 'mountNode2',
        unit: '%',
        colors: ['#a32d6b']
      });
    }
  })
  $.ajax({
    url: `http://${window.url}/wuling/resource/averageCpu`,
    data: {},
    type: 'POST',
    dataType: 'json',
    success: function(res) {
      let data = res.responseBody
      data = data.map(item => {
        item.used = Number(item.used)
        return item
      })
      intervalChart3 = createChart(data, {
        container: 'mountNode3',
        unit: '%',
        colors: ['#94faff']
      });
    }
  })
}
// 初始化曲线图
let lineChart1 = null
let lineChart2 = null
let lineChart3 = null
function initLine() {
  $.ajax({
    url: `http://${window.url}/wuling/resource/virtualUsed`,
    data: {},
    type: 'POST',
    dataType: 'json',
    success: function(res) {
      let data = res.responseBody
      data = data.map(item => {
        item.used = Number(item.used)
        return item
      })
      lineChart1 = createRightChart(data, {
        container: 'mountNode4',
        unit: '%',
        flag: true,
        colors: ['#14C8EE', '#EEC414', '#1454EE', '#A06A61']
      });
    }
  })
  $.ajax({
    url: `http://${window.url}/wuling/equipment/memoryUsed`,
    data: {},
    type: 'POST',
    dataType: 'json',
    success: function(res) {
      let data = res.responseBody
      data = data.map(item => {
        item.used = Number(item.used)
        return item
      })
      lineChart2 = createRightChart(data, {
        container: 'mountNode5',
        unit: '%',
        useunit: true,
        colors: ['#1454EE']
      });
    }
  })
  $.ajax({
    url: `http://${window.url}/wuling/equipment/cpuUsed`,
    data: {},
    type: 'POST',
    dataType: 'json',
    success: function(res) {
      let data = res.responseBody
      data = data.map(item => {
        item.used = Number(item.used)
        return item
      })
      lineChart3 = createRightChart(data, {
        container: 'mountNode6',
        unit: '%',
        colors: ['#EEC414', '#1454EE']
      });
    }
  })
}

// 更新饼状图数据
function updatePie(network, system) {
  pieChart1.changeData(transformPieData(network))
  pieChart2.changeData(transformPieData(system))
}
// 更新柱状图数据
function updateInterval(arr1,arr3) {
  $.ajax({
    url: `http://${window.url}/wuling/resource/memoryUsed`,
    data: {},
    type: 'POST',
    dataType: 'json',
    success: function(res) {
      let data = res.responseBody
      data = data.map(item => {
        item.used = Number(item.used)
        return item
      })
      intervalChart1.changeData(data)
    }
  })
  $.ajax({
    url: `http://${window.url}/wuling/resource/dataSet`,
    data: {},
    type: 'POST',
    dataType: 'json',
    success: function(res) {
      let data = res.responseBody
      data = data.map(item => {
        item.used = Number(item.used)
        return item
      })
      intervalChart2.changeData(data)
    }
  })
  $.ajax({
    url: `http://${window.url}/wuling/resource/averageCpu`,
    data: {},
    type: 'POST',
    dataType: 'json',
    success: function(res) {
      let data = res.responseBody
      data = data.map(item => {
        item.used = Number(item.used)
        return item
      })
      intervalChart3.changeData(data)
    }
  })
}
// 更新曲线图
function updateLine() {
  $.ajax({
    url: `http://${window.url}/wuling/resource/virtualUsed`,
    data: {},
    type: 'POST',
    dataType: 'json',
    success: function(res) {
      let data = res.responseBody
      data = data.map(item => {
        item.used = Number(item.used)
        return item
      })
      lineChart1.changeData(data)
    }
  })
  $.ajax({
    url: `http://${window.url}/wuling/equipment/memoryUsed`,
    data: {},
    type: 'POST',
    dataType: 'json',
    success: function(res) {
      let data = res.responseBody
      data = data.map(item => {
        item.used = Number(item.used)
        return item
      })
      lineChart2.changeData(data)
    }
  })
  $.ajax({
    url: `http://${window.url}/wuling/equipment/cpuUsed`,
    data: {},
    type: 'POST',
    dataType: 'json',
    success: function(res) {
      let data = res.responseBody
      data = data.map(item => {
        item.used = Number(item.used)
        return item
      })
      lineChart3.changeData(data)
    }
  })
}

// ========================  后台对接数据  =============================
// 模拟数据
var intervalData = [
  {
    name: '已使用',
    time:'09-15',
    used:50
  },{
    name: '已使用',
    time:'09-16',
    used:50
  },{
    name: '已使用',
    time:'09-17',
    used:50
  },{
    name: '已使用',
    time:'09-18',
    used:50
  },{
    name: '已使用',
    time:'09-19',
    used:50
  },{
    name: '已使用',
    time:'09-20',
    used:50
  },{
    name: '已使用',
    time:'09-21',
    used:50
  },{
    name: '已使用',
    time:'09-22',
    used:50
  },{
    name: '已使用',
    time:'09-23',
    used:50
  },{
    name: '已使用',
    time:'09-24',
    used:50
  },{
    name: '已使用',
    time:'09-25',
    used:50
  },{
    name: '已使用',
    time:'09-26',
    used:50
  },{
    name: '已使用',
    time:'09-27',
    used:50
  },{
    name: '已使用',
    time:'09-28',
    used:50
  },{
    name: '已使用',
    time:'09-29',
    used:50
  },{
    name: '已使用',
    time:'09-30',
    used:50
  }
];
let intervalData1 = [
  {
    time:'10-25 9',
    used:4
  },{
    time:'10-26 10',
    used:4
  },{
    time:'10-27 11',
    used:4
  },{
    time:'10-28 12',
    used:4
  },{
    time:'10-29 13',
    used:4
  },{
    time:'10-30 14',
    used:4
  },{
    time:'10-31 15',
    used:4
  },{
    time:'10-32 16',
    used:4
  },{
    time:'10-33 17',
    used:4
  },{
    time:'10-34 18',
    used:4
  },{
    time:'10-35 19',
    used:5
  },{
    time:'10-36 12',
    used:4
  },{
    time:'10-37 13',
    used:4
  },{
    time:'10-38 14',
    used:4
  },{
    time:'10-39 15',
    used:4
  },{
    time:'10-40 16',
    used:4
  },{
    time:'10-41 17',
    used:4
  },{
    time:'10-42 18',
    used:4
  },{
    time:'10-43 19',
    used:5
  }
]
var lineData1 = [
  { 'time': '11-15 11:00', 'used': 10, 'group': '内存比例' },
  { 'time': '11-16 19:00', 'used': 12, 'group': '内存比例' },
  { 'time': '11-18 00:00', 'used': 25, 'group': '内存比例' },
  { 'time': '11-19 05:00', 'used': 78, 'group': '内存比例' },
  { 'time': '11-20 10:00', 'used': 45, 'group': '内存比例' },
  { 'time': '11-15 11:00', 'used': 74, 'group': '虚拟磁盘比例' },
  { 'time': '11-16 19:00', 'used': 12, 'group': '虚拟磁盘比例' },
  { 'time': '11-18 00:00', 'used': 54, 'group': '虚拟磁盘比例' },
  { 'time': '11-19 05:00', 'used': 2, 'group': '虚拟磁盘比例' },
  { 'time': '11-20 10:00', 'used': 68, 'group': '虚拟磁盘比例' },
  { 'time': '11-15 11:00', 'used': 35, 'group': '主机比例' },
  { 'time': '11-16 19:00', 'used': 21, 'group': '主机比例' },
  { 'time': '11-18 00:00', 'used': 89, 'group': '主机比例' },
  { 'time': '11-19 05:00', 'used': 45, 'group': '主机比例' },
  { 'time': '11-20 10:00', 'used': 12, 'group': '主机比例' },
  { 'time': '11-15 11:00', 'used': 12, 'group': 'VCPU比例' },
  { 'time': '11-16 19:00', 'used': 75, 'group': 'VCPU比例' },
  { 'time': '11-18 00:00', 'used': 65, 'group': 'VCPU比例' },
  { 'time': '11-19 05:00', 'used': 43, 'group': 'VCPU比例' },
  { 'time': '11-20 10:00', 'used': 45, 'group': 'VCPU比例' }
];
var lineData2 = [
  { 'time': '11-15 11:00', 'used': 47, 'group': '内存使用率' },
  { 'time': '11-16 20:00', 'used': 12, 'group': '内存使用率' },
  { 'time': '11-18 02:00', 'used': 78, 'group': '内存使用率' },
  { 'time': '11-19 08:00', 'used': 35, 'group': '内存使用率' },
  { 'time': '11-20 14:00', 'used': 1, 'group': '内存使用率' },
  { 'time': '11-21 20:00', 'used': 54, 'group': '内存使用率' },
  { 'time': '11-22 10:00', 'used': 68, 'group': '内存使用率' }
];
var lineData3 = [
  { time: '11-15 11:00', used: 12, group: 'CPU使用率' },
  { time: '11-16 20:00', used: 45, group: 'CPU使用率' },
  { time: '11-18 02:00', used: 34, group: 'CPU使用率' },
  { time: '11-19 08:00', used: 78, group: 'CPU使用率' },
  { time: '11-20 14:00', used: 55, group: 'CPU使用率' },
  { time: '11-21 20:00', used: 87, group: 'CPU使用率' },
  { time: '11-22 10:00', used: 95, group: 'CPU使用率' }
];
var pieData1 = [
  {
    'item': '灾难',
    'count': 2
  },
  {
    'item': '严重',
    'count': 4
  },
  {
    'item': '一般',
    'count': 6
  },
  {
    'item': '警告',
    'count': 8
  }
];
var pieData2 = [
  {
    item: '灾难',
    count: 10
  },
  {
    item: '严重',
    count:0
  },
  {
    item: '一般',
    count: 0
  },
  {
    item: '警告',
    count: 0
  }
];
let overallData = [
  {
    title: '主机数量',
    total: 984,
    used: 872,
    unit: '台'
  },{
    title: '硬盘数量',
    total: 1546,
    used: 272,
    unit: '台'
  },{
    title: 'HyperNodes数量',
    total: 2352,
    used: 1234,
    unit: '台'
  }
]
let warningData = [
  {
    warn: '[Compute OS]Memory Usage HIGH on server hsing shihai shuahuig sjone '
  }, {
    warn: '[Compute OS]Memory Usage HIGH on server'
  }, {
    warn: '[Compute OS]Memory Usage HIGH on server'
  }, {
    warn: '[Compute OS]Memory Usage HIGH on server'
  }, {
    warn: '[Compute OS]Memory Usage HIGH on server'
  }
]
let groupData = [
  {
    group: '',
    name: '网络设备',
    group1: '',
    name1: '操作系统'
  }
]

// 初始化
setGroupData(groupData)

setOverallData()
setWarningData()
setMachineData()
initInterval()
initLine()

setInterval(setOverallData, 60000)
setInterval(setWarningData, 60000)
setInterval(setMachineData, 60000)
setInterval(updateInterval, 60000)
setInterval(updateLine, 60000)