function createRose(data,options) {
  var chart = new G2.Chart({
    container: options.container,
    forceFit: true,
    height: 153,
    padding: [0, 0, 0, 0]
  });
  chart.source(data);
  chart.coord('polar');
  chart.legend(false);
  chart.axis(false);
  chart.interval().position('item*count').color('item',["#943060", "#a06a61", "#2c7db5", "#3ca59b"]).style({
    lineWidth: 1,
    stroke: '#fff'
  });
  chart.render();
}